# NTCIR15 TOOLS

This package contains tools for NTCIR15 data search task
